CREATE TABLE disease (
  id_tanaman INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  jenis_tanaman VARCHAR NULL,
  nama_masyarakat VARCHAR NULL,
  nama_ilmiah VARCHAR NULL,
  deskripsi_penyakit VARCHAR NULL,
  gejala VARCHAR NULL,
  tindakan_pencegahan VARCHAR NULL,
  penyebab VARCHAR NULL,
  potensi_tanaman VARCHAR NULL,
  cara_pengobatan VARCHAR NULL,
  foto_penyakit VARCHAR NULL,
  PRIMARY KEY(id_tanaman)
);

CREATE TABLE financial_dashboard (
  id_financial INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  user_profile_id_user INTEGER UNSIGNED NOT NULL,
  date_time DATETIME NULL,
  pemasukkan INTEGER UNSIGNED NULL,
  pengeluaran INTEGER UNSIGNED NULL,
  desc_pemasukan VARCHAR() NULL,
  desc_pengeluaran VARCHAR NULL,
  PRIMARY KEY(id_financial),
  INDEX financial_dashboard_FKIndex1(user_profile_id_user)
);

CREATE TABLE plant_information (
  id_tanaman INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  nama_masyarakat VARCHAR NULL,
  nama_spesies VARCHAR NULL,
  genus VARCHAR NULL,
  ordo VARCHAR NULL,
  deskripsi_tanaman VARCHAR NULL,
  memilih_tanaman VARCHAR NULL,
  penanaman VARCHAR NULL,
  lokasi_optimal VARCHAR NULL,
  penyakit_tanaman VARCHAR NULL,
  pencegahan_penyakit VARCHAR NULL,
  tingkat_kesulitan VARCHAR(10) NULL,
  harga VARCHAR NULL,
  foto_tanaman VARCHAR NULL,
  PRIMARY KEY(id_tanaman)
);

CREATE TABLE plant_information_has_disease (
  plant_information_id_tanaman INTEGER UNSIGNED NOT NULL,
  disease_id_tanaman INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY(plant_information_id_tanaman, disease_id_tanaman),
  INDEX plant_information_has_disease_FKIndex1(plant_information_id_tanaman),
  INDEX plant_information_has_disease_FKIndex2(disease_id_tanaman)
);

CREATE TABLE user_profile (
  id_user INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  lokasi VARCHAR NULL,
  nama VARCHAR NULL,
  pass VARCHAR NULL,
  jenis_kelamin VARCHAR NULL,
  point INTEGER(20) UNSIGNED NULL,
  badge VARCHAR(16) NULL,
  email VARCHAR NULL,
  telepon INTEGER(20) UNSIGNED NULL,
  foto_profile VARCHAR NULL,
  PRIMARY KEY(id_user)
);

CREATE TABLE user_profile_has_plant_information (
  user_profile_id_user INTEGER UNSIGNED NOT NULL,
  plant_information_id_tanaman INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY(user_profile_id_user, plant_information_id_tanaman),
  INDEX user_profile_has_plant_information_FKIndex1(user_profile_id_user),
  INDEX user_profile_has_plant_information_FKIndex2(plant_information_id_tanaman)
);


