CREATE TABLE disease (
  id_tanaman INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  plant_infor_id_tanaman INTEGER UNSIGNED NOT NULL,
  date_time DATETIME NULL,
  jns_tnm VARCHAR(255) NULL,
  nm_ilm VARCHAR(255) NULL,
  nm_msy VARCHAR(255) NULL,
  dsk_skt VARCHAR(255) NULL,
  gjl_skt VARCHAR(255) NULL,
  tdk_cgh VARCHAR(255) NULL,
  penyebab VARCHAR(255) NULL,
  ptn_tnm VARCHAR(50) NULL,
  foto_skt BLOB NULL,
  PRIMARY KEY(id_tanaman, plant_infor_id_tanaman),
  INDEX plant_disease_data_FKIndex1(plant_infor_id_tanaman)
);

CREATE TABLE financial_dashboard (
  user_id INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  user_profile_user_id INTEGER UNSIGNED NOT NULL,
  date_time DATETIME NULL,
  pemasukkan INTEGER UNSIGNED NULL,
  pengeluaran INTEGER UNSIGNED NULL,
  tipe_msk VARCHAR(255) NULL,
  tipe_out VARCHAR(255) NULL,
  PRIMARY KEY(user_id, user_profile_user_id),
  INDEX financial_dashboard_FKIndex1(user_profile_user_id)
);

CREATE TABLE forum (
  id_post INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id_post INTEGER UNSIGNED NOT NULL,
  post_disease_id_tanaman INTEGER UNSIGNED NOT NULL,
  post_disease_plant_infor_id_tanaman INTEGER UNSIGNED NOT NULL,
  id_comment INTEGER UNSIGNED NULL,
  isi_comment VARCHAR(255) NULL,
  date_time DATETIME NULL,
  jml_like INTEGER UNSIGNED NULL,
  user_id INTEGER UNSIGNED NULL,
  PRIMARY KEY(id_post, post_id_post, post_disease_id_tanaman, post_disease_plant_infor_id_tanaman),
  INDEX comment_community_forum_FKIndex1(post_id_post, post_disease_id_tanaman, post_disease_plant_infor_id_tanaman)
);

CREATE TABLE plant_infor (
  id_tanaman INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  financial_dashboard_user_profile_user_id INTEGER UNSIGNED NOT NULL,
  financial_dashboard_user_id INTEGER UNSIGNED NOT NULL,
  date_time DATETIME NULL,
  nm_msy VARCHAR(255) NOT NULL,
  nm_sps VARCHAR(255) NULL,
  genus VARCHAR(50) NULL,
  ordo VARCHAR(50) NULL,
  dsk_tnm VARCHAR(255) NULL,
  cr_mml_tnm VARCHAR(255) NULL,
  cr_pnnm VARCHAR(255) NULL,
  lok_opt_bdy VARCHAR(50) NULL,
  tdk_cgh_skt VARCHAR(255) NULL,
  tkt_slt_rwt VARCHAR(255) NULL,
  skt_tnm VARCHAR(50) NULL,
  jns_tnh VARCHAR(50) NULL,
  kdr_air VARCHAR(50) NULL,
  wkt_pn DATE NULL,
  harga INTEGER UNSIGNED NULL,
  foto_tnm BLOB NULL,
  PRIMARY KEY(id_tanaman),
  INDEX ornamental_plant_information_FKIndex1(financial_dashboard_user_id, financial_dashboard_user_profile_user_id)
);

CREATE TABLE post (
  id_post INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  disease_id_tanaman INTEGER UNSIGNED NOT NULL,
  disease_plant_infor_id_tanaman INTEGER UNSIGNED NOT NULL,
  judul VARCHAR(255) NULL,
  isi_post VARCHAR(255) NULL,
  date_time DATETIME NULL,
  jml_kom INTEGER UNSIGNED NULL,
  jml_like INTEGER UNSIGNED NULL,
  jml_share INTEGER UNSIGNED NULL,
  foto_up BLOB NULL,
  user_id INTEGER UNSIGNED NULL,
  PRIMARY KEY(id_post, disease_id_tanaman, disease_plant_infor_id_tanaman),
  INDEX post_community_forum_FKIndex1(disease_id_tanaman, disease_plant_infor_id_tanaman)
);

CREATE TABLE user_profile (
  user_id INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  forum_post_disease_plant_infor_id_tanaman INTEGER UNSIGNED NOT NULL,
  forum_post_id_post INTEGER UNSIGNED NOT NULL,
  forum_id_post INTEGER UNSIGNED NOT NULL,
  forum_post_disease_id_tanaman INTEGER UNSIGNED NOT NULL,
  lokasi VARCHAR(255) NULL,
  nama VARCHAR(255) NULL,
  pass VARCHAR(50) NULL,
  jk VARCHAR(50) NULL,
  point INTEGER(20) UNSIGNED NULL,
  badge VARCHAR(255) NULL,
  email VARCHAR(255) NULL,
  telepon INTEGER(20) UNSIGNED NULL,
  profesi VARCHAR(50) NULL,
  foto_pp BLOB NULL,
  PRIMARY KEY(user_id),
  INDEX user_profile_FKIndex1(forum_id_post, forum_post_id_post, forum_post_disease_id_tanaman, forum_post_disease_plant_infor_id_tanaman)
);


